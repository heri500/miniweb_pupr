<?php

namespace Drupal\frontpage_main\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\views\Views;

/**
 * Provides a 'Frontpage Main' Block.
 *
 * @Block(
 *   id = "frontpage_main_block",
 *   admin_label = @Translation("Frontpage Main Block"),
 * )
 */
class FrontpageMainBlock extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function build() {
    // Load views as objects (not rendered)
    $main = $this->getViewResult('main_content_highlight', 'default');
    $second = $this->getViewResult('second_content_highlight', 'default');
    $third = $this->getViewResult('front_content_highlight', 'default');

    return [
      '#theme' => 'item_list',
      '#items' => [
        ['#markup' => '<pre>' . print_r($main, TRUE) . '</pre>'],
        ['#markup' => '<pre>' . print_r($second, TRUE) . '</pre>'],
        ['#markup' => '<pre>' . print_r($third, TRUE) . '</pre>'],
      ],
    ];
  }

  /**
   * Get the result object from a view.
   *
   * @param string $view_id
   * @param string $display_id
   *
   * @return array|null
   */
  protected function getViewResult(string $view_id, string $display_id = 'default') {
    $view = Views::getView($view_id);
    if ($view && $view->access($display_id)) {
      $view->setDisplay($display_id);
      $view->preExecute();
      $view->execute();
      return $view->result; // This is an array of view row result objects
    }
    return NULL;
  }
}
